package com.example.dz31;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {
    TextView mainText;
    ImageButton mainBtn;
    ImageButton mainBtn2;
    ImageButton mainBtn3;
    private long score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainText = (TextView) findViewById(R.id.mainTxt);
        mainBtn = (ImageButton) findViewById(R.id.main_btn);
        mainBtn2 = (ImageButton) findViewById(R.id.main_btn2);
        mainBtn3 = (ImageButton) findViewById(R.id.main_btn3);
        mainBtn.setOnClickListener(clickListener);
        mainBtn2.setOnClickListener(clickListener2);
        mainBtn3.setOnClickListener(clickListener3);
    }
    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            score++;
            String s;
            if ((score% 100 == 12) || (score% 100 == 13) || (score% 100 == 14)){
                s = "Кнопка нажата " + score + " раз";
            }else if ((score%10 == 4) || (score%10 == 3)||(score%10 == 2)){
                s = "Кнопка нажата " + score + " раза";
            } else {
                s = "Кнопка нажата "+ score + " раз";
            }
            mainText.setText(s.toCharArray(), 0, s.length());
        }
    };

    View.OnClickListener clickListener2 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String s;
            if (score <= 0){
                score = 0;
            } else {
                score --;
                if ((score% 100 == 12) || (score% 100 == 13) || (score% 100 == 14)){
                    s = "Кнопка нажата " + score + " раз";
                }else if ((score%10 == 4) || (score%10 == 3)||(score%10 == 2)){
                    s = "Кнопка нажата " + score + " раза";
                } else {
                    s = "Кнопка нажата " + score + " раз";
                }
                mainText.setText(s.toCharArray(), 0, s.length());
            }
        }
    };

    View.OnClickListener clickListener3 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            score = 0;
            String s = "Кликов: " + score;
            mainText.setText(s.toCharArray(), 0, s.length());
        }
    };
}
