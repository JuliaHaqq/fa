package com.example.md22;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class change extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    TextView colorZZ;
    Button ba;
    String test;
    String test2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change);

        colorZZ = (TextView) findViewById(R.id.colorZZ);
        ba = (Button) findViewById(R.id.ba);

        Spinner spinner1 = findViewById(R.id.spinner1);
        spinner1.setOnItemSelectedListener(this);

        Spinner spinner2 = findViewById(R.id.spinner2);
        spinner2.setOnItemSelectedListener(this);
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(this,adapterView.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
        switch(adapterView.getSelectedItem().toString()) {

            case "Пурпур":
                colorZZ.setTextColor(Color.rgb(128,0,128));
                test = "Пурпур";
                break;
            case "Синий":
                colorZZ.setTextColor(Color.rgb(25,25,255));
                test = "Синий";
                break;
            case "Центр":
                colorZZ.setGravity(Gravity.CENTER);
                test2 = "Центр";
                break;
            case "Справа":
                colorZZ.setGravity(Gravity.RIGHT);
                test2 = "Справа";
                break;
        }
    }
    public void onClick(View v) {

        Intent intent;
        switch (v.getId()) {
            case R.id.ba:
                intent = new Intent(this, MainActivity.class);
                intent.putExtra("test", test);
                intent.putExtra("test2", test2);
                setResult(RESULT_OK, intent);
                finish();
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}