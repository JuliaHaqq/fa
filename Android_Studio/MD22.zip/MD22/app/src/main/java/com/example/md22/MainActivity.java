package com.example.md22;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnTime, btnDate, btnName, dop1B, dop2B, dop3B;
    EditText etLName, dop1ET;
    TextView tvName, colorZZ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTime = findViewById(R.id.btnTime);
        btnDate = findViewById(R.id.btnDate);
        btnName = findViewById(R.id.btnName);
        etLName = findViewById(R.id.etLName);
        tvName = findViewById(R.id.tvName);
        dop1B = findViewById(R.id.dop1B);
        dop1ET = findViewById(R.id.dop1ET);
        dop2B = findViewById(R.id.dop2B);
        dop3B = findViewById(R.id.dop3B);
        colorZZ = findViewById(R.id.colorZZ);

        btnTime.setOnClickListener(this);
        btnDate.setOnClickListener(this);
        btnName.setOnClickListener(this);
        dop1B.setOnClickListener(this);
        dop2B.setOnClickListener(this);
        dop3B.setOnClickListener(this);

    }


    public void onClick(View v) {
        Intent intent;
        switch(v.getId()) {
            case R.id.btnTime:
                intent = new Intent("com.example.intent.action.showtime");
                intent.putExtra("lname", etLName.getText().toString());
                startActivity(intent);
                break;
            case R.id.btnDate:
                intent = new Intent("com.example.intent.action.showdate");
                intent.putExtra("lname", etLName.getText().toString());
                startActivity(intent);
                break;
            case R.id.btnName:
                intent = new Intent(this, NameActivity.class);
                startActivityForResult(intent, 1);
                break;
            case R.id.dop1B:
                String url = dop1ET.getText().toString();
                if (!url.startsWith("http://") && !url.startsWith("https://")){
                    url = "http://" + url;}
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
            case R.id.dop2B:
                intent = new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);
                startActivity(intent);
            case R.id.dop3B:
                intent = new Intent(this, change.class);
                startActivityForResult(intent,1);

        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data == null) {return;}
        String name = data.getStringExtra("name");
        tvName.setText("Your name is " + name);

        if (requestCode == 1) {

          //  String txtcolor = getIntent().getStringExtra("test");
         //   String txtshr = getIntent().getStringExtra("test2");

            String txtcolor = (String) data.getExtras().get("test");
            String txtshr = (String) data.getExtras().get("test2");

            Toast.makeText(this,txtcolor, Toast.LENGTH_SHORT).show();

            if (txtcolor.equals("Синий")) {
                colorZZ.setTextColor(Color.rgb(25, 25, 255));
            } else {
                colorZZ.setTextColor(Color.rgb(128,0,128));
            }
            if (txtshr.equals("Центр")) {
                colorZZ.setGravity(Gravity.CENTER);
            } else {
                colorZZ.setGravity(Gravity.CENTER);
            }
        }
    }
}